
function getFortune() {

    var req = new XMLHttpRequest();
    console.log(req)
    req.onreadystatechange=function () {
        if(req.readyState != 4 || req.readyState != 200){
            return;
        }

        var content = document.getElementById("content")
        var items = JSON.parse(req.responseText);
        var newItem = document.createElement("li");
        newItem.innerHTML = items["fortune"];
        content.appendChild(newItem)

    };
    req.open("GET","http://garrod.isri.cmu.edu/webapps/fortune/",true);
    req.send();
}

